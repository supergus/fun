import fun

fun.et.phone_home('howdy', 7345454764)
