"""This is the mostest awesomeset package EVAR."""

__author__ = "Christopher Couch"
__license__ = "Strictly proprietary for Liveline Technologies, Inc."
__version__ = "2020-11"


from fun.printing.formatted_console_print import fancy_print
from fun.communications import communicator as et
